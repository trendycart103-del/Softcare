package com.example.bubbleplayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.database.Cursor;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static final int[][] THEMES = {
        {0xFF0F2027, 0xFF2C5364, 0xFF4FC3F7},
        {0xFF3A1C71, 0xFFD76D77, 0xFFFFAF7B},
        {0xFF000000, 0xFF434343, 0xFFFFFFFF},
        {0xFF134E5E, 0xFF71B280, 0xFFB9FBC0},
        {0xFF42275A, 0xFF734B6D, 0xFFF48FB1}};
    ArrayList<String> titles = new ArrayList<>();
    ArrayList<Uri> uris = new ArrayList<>();
    MediaPlayer mp;
    int idx = -1;
    BubbleView bv;
    TextView name, time;
    SeekBar seek;
    Button play;
    SharedPreferences sp;
    long sleepEnd = 0;
    TextView timerTxt;
    Handler h = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        FrameLayout root = new FrameLayout(this);
        bv = new BubbleView(this);
        root.addView(bv);
        applyCfg();
        LinearLayout ui = new LinearLayout(this);
        ui.setOrientation(LinearLayout.VERTICAL);
        ui.setGravity(Gravity.CENTER);
        ui.setPadding(40, 80, 40, 80);
        name = txt("গান বেছে নিন", 24);
        time = txt("0:00", 14);
        seek = new SeekBar(this);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.addView(btn("⏮", v -> step(-1)));
        play = btn("▶", v -> toggle());
        row.addView(play);
        row.addView(btn("⏭", v -> step(1)));
        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER);
        row2.addView(btn("☰ লিস্ট", v -> showList()));
        row2.addView(btn("🎨 কাস্টমাইজ", v -> showCustom()));
        LinearLayout row3 = new LinearLayout(this);
        row3.setGravity(Gravity.CENTER);
        row3.addView(btn("⏰ টাইমার", v -> showTimer()));
        timerTxt = txt("", 14);
        ui.addView(name); ui.addView(seek); ui.addView(time); ui.addView(row); ui.addView(row2);
        ui.addView(row3); ui.addView(timerTxt);
        root.addView(ui);
        setContentView(root);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { if (u && mp != null) mp.seekTo(p); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        tick();
        String perm = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(perm) == 0) load(); else requestPermissions(new String[]{perm}, 1);
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (r.length > 0 && r[0] == 0) load();
        else Toast.makeText(this, "গান পড়তে অনুমতি দরকার", Toast.LENGTH_LONG).show();
    }

    TextView txt(String s, int sz) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sz); t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER);
        t.setPadding(0, 20, 0, 20);
        return t;
    }

    Button btn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(12, 12, 12, 12);
        b.setLayoutParams(p);
        b.setOnClickListener(l);
        return b;
    }

    void applyCfg() {
        int[] t = THEMES[sp.getInt("theme", 0)];
        bv.config(sp.getInt("count", 30), sp.getInt("speed", 3), t[0], t[1], t[2]);
    }

    void load() {
        titles.clear(); uris.clear();
        try (Cursor c = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE},
                MediaStore.Audio.Media.IS_MUSIC + "!=0", null, MediaStore.Audio.Media.TITLE)) {
            while (c != null && c.moveToNext()) {
                uris.add(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0)));
                titles.add(c.getString(1));
            }
        }
        if (uris.isEmpty()) name.setText("কোনো গান পাওয়া যায়নি");
    }

    void showList() {
        if (titles.isEmpty()) return;
        new AlertDialog.Builder(this).setTitle("গানের তালিকা")
            .setItems(titles.toArray(new String[0]), (d, i) -> start(i)).show();
    }

    void start(int i) {
        try {
            if (mp != null) mp.release();
            idx = i;
            mp = new MediaPlayer();
            mp.setDataSource(this, uris.get(i));
            mp.prepare();
            mp.setOnCompletionListener(m -> step(1));
            mp.start();
            name.setText(titles.get(i));
            seek.setMax(mp.getDuration());
            sync();
        } catch (Exception e) {
            Toast.makeText(this, "চালানো যায়নি", Toast.LENGTH_SHORT).show();
        }
    }

    void step(int d) {
        if (uris.isEmpty()) return;
        start((idx + d + uris.size()) % uris.size());
    }

    void toggle() {
        if (mp == null) { if (!uris.isEmpty()) start(0); return; }
        if (mp.isPlaying()) mp.pause(); else mp.start();
        sync();
    }

    void sync() {
        boolean p = mp != null && mp.isPlaying();
        play.setText(p ? "⏸" : "▶");
        bv.playing = p;
    }

    void tick() {
        if (mp != null) {
            try {
                seek.setProgress(mp.getCurrentPosition());
                int s = mp.getCurrentPosition() / 1000;
                time.setText(s / 60 + ":" + String.format("%02d", s % 60));
            } catch (Exception ignored) {}
        }
        if (sleepEnd > 0) {
            long left = (sleepEnd - System.currentTimeMillis()) / 1000;
            if (left <= 0) {
                sleepEnd = 0;
                timerTxt.setText("");
                if (mp != null && mp.isPlaying()) mp.pause();
                sync();
                Toast.makeText(this, "টাইমার শেষ, গান বন্ধ হয়েছে", Toast.LENGTH_LONG).show();
            } else {
                timerTxt.setText("⏰ বাকি: " + left / 60 + ":" + String.format("%02d", left % 60));
            }
        }
        h.postDelayed(this::tick, 500);
    }

    void setSleep(int min) {
        sleepEnd = min > 0 ? System.currentTimeMillis() + min * 60000L : 0;
        if (min <= 0) timerTxt.setText("");
        else Toast.makeText(this, min + " মিনিট পরে গান বন্ধ হবে", Toast.LENGTH_SHORT).show();
    }

    void showTimer() {
        final int[] mins = {5, 10, 15, 30, 45, 60, 90};
        String[] items = new String[mins.length + 2];
        for (int i = 0; i < mins.length; i++) items[i] = mins[i] + " মিনিট";
        items[mins.length] = "নিজে সময় লিখুন";
        items[mins.length + 1] = "টাইমার বাতিল";
        new AlertDialog.Builder(this).setTitle("স্লিপ টাইমার").setItems(items, (d, i) -> {
            if (i < mins.length) setSleep(mins[i]);
            else if (i == mins.length) {
                EditText e = new EditText(this);
                e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
                e.setHint("মিনিট (যেমন 20)");
                new AlertDialog.Builder(this).setTitle("কত মিনিট?").setView(e)
                    .setPositiveButton("সেট", (dd, w) -> {
                        try { setSleep(Integer.parseInt(e.getText().toString().trim())); }
                        catch (Exception ex) { Toast.makeText(this, "সঠিক সংখ্যা দিন", Toast.LENGTH_SHORT).show(); }
                    }).setNegativeButton("বাদ", null).show();
            } else setSleep(0);
        }).show();
    }

    void showCustom() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(50, 30, 50, 10);
        Button th = new Button(this);
        th.setText("থিম বদলান");
        th.setOnClickListener(v -> {
            sp.edit().putInt("theme", (sp.getInt("theme", 0) + 1) % THEMES.length).apply();
            applyCfg();
        });
        l.addView(th);
        l.addView(slider("বাবলের সংখ্যা", "count", 5, 80, 30));
        l.addView(slider("গতি", "speed", 1, 10, 3));
        new AlertDialog.Builder(this).setTitle("কাস্টমাইজ").setView(l).setPositiveButton("ঠিক আছে", null).show();
    }

    View slider(String label, String key, int min, int max, int def) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(label);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(sp.getInt(key, def) - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                if (u) { sp.edit().putInt(key, p + min).apply(); applyCfg(); }
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        l.addView(t); l.addView(s);
        return l;
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (mp != null) mp.release();
    }
}
